#include<iostream>
using namespace std;
class stack {
            public :
            stack() { top=0; }
            int push(int value)
            { if (top+1<=maxsize)  {
                                                top++;
                                                V[top]=value;
                                                return 1;}
               return 0;}
            int pop(int *old);
            int whatheight() { return top;}
            int isempty() { return (top<1);}
            private :
            int top;
            int V[100];
            int maxsize=100;
         };
int n;
stack somestack;
int vf;
int init(stack somestack)
{
    somestack.push(0);
}
int tipar(stack somestack)
{
    cout<<endl;
    for(int i=1;i<somestack.whatheight();i++) cout<<" "<<somestack.whatheight();
}
int solutie(stack somestack)
{
    if(somestack.whatheight()==(n+1)) return 1;
    else return 0;
}
int succesor(stack somestack)
{
    if(somestack.whatheight()<n){somestack.whatheight()++;
                 return 1;  }
                 else return 0;
}
int valid(stack somestack)
{
    if(vf==1) return 1;
    else
        for(int i=1;i<vf;i++)
    {
        if(somestack==somestack.whatheight()) return 0;
    }
    return 1;
}
